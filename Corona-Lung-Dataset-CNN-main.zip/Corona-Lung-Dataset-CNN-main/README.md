Corona Lung Dataset--CNN

